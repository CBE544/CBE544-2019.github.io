#!/usr/bin/env python

import numpy as np
from ase.io import Trajectory
from ase.calculators.vasp import Vasp
from ase.io import read,write

eps=0.03	#range to test
a0=2.835	#a lattice constant
c0=4.71		#final term in the c lattice vector
a=[a0,0,0]
b=[a0/2,(a0/2)*np.sqrt(3),0]
c=[a0/2,a0/(2*np.sqrt(3)),c0]
for X in np.linspace(1-eps,1+eps,7): #This sets the # of calculations we do within our range
	p=read('LiCoO2-bulk.traj') #bulk LiCoO2.traj
 	p.set_cell([[X*a[0],X*a[1],X*a[2]],[X*b[0],X*b[1],X*b[2]],[c[0],c[1],c[2]]],scale_atoms=True) #scale the unit cell in a and b by X
	calc = Vasp(prec='accurate',
            encut=520,
            xc='PBE',
            lreal='Auto',
            kpts=[9,9,5],
            nsw = 0,
            ibrion = 2,
            amix_mag = 0.800000,
            bmix = 0.000100,
            bmix_mag= 0.000100,
            amix = 0.20000,
            sigma = 0.05000,
            ediff = 2.00e-04,
            ediffg = -2.00e-02,
            algo ='fast',
            ismear = -5,
            nelm = 250,
            ncore = 16,
            lasph= True,
            ldautype = 2,
            lmaxmix = 4,
            lorbit = 11,
            ldau = True,
            ldauprint = 2,
            ldau_luj={'Co':{'L':2, 'U':3.32, 'J':0.0},
                      'Li':{'L':-1, 'U':0.0, 'J':0.0},
                      'O':{'L':-1, 'U':0.0, 'J':0.0}
                      },
            lvtot = False,
            lwave = False,
            lcharg = False,
	    gamma=True,
)	

	
	p.set_calculator(calc)
	p.get_potential_energy()
	traj=Trajectory('LiCoO2.traj','a')
        traj.write(p)
